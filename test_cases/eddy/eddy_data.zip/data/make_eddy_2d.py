import xarray as xr
import numpy as np
import os, sys

fname_out = './data/eddy_2d.nc'
if (os.path.exists(fname_out) == False):
    print("Generating eddy data...")
    
    # Make a fake dataset
    x = np.linspace(-10, 10, 600)
    y = np.linspace(-10, 10, 500)
    
    xx, yy = np.meshgrid(x, y)
    
    u = np.ones(shape=(100, 500, 600))*-np.cos(np.pi/180.)*yy*10.
    v = np.ones(shape=(100, 500, 600))*np.cos(np.pi/180.)*xx*10.
    
    # Save to netCDF
    ds = xr.Dataset(
        data_vars={
            'u': (('time',  'lat', 'lon'), u),
            'v': (('time',  'lat', 'lon'), v),
        },
        coords={
            'time': np.arange(100)*600,
            'lat': y,
            'lon': x,
        },
    )
    ds.time.attrs['units'] = 'seconds since 2018-01-01 00:00:00'
    encoding = {
        'time': {'dtype': 'float64'},
        'lon': {'dtype': 'float64'},
        'lat': {'dtype': 'float64'},
    }
    
    ds.to_netcdf(fname_out, encoding=encoding)
    print("Saved to ./data/eddy_2d.nc")
    
    
    fname_out = './eddy_topo.nc'
    if (os.path.exists(fname_out) == False):
        # Save topo
        print("Generating eddy topo...")
        
        bathy = np.ones_like(xx)*10.
        ds = xr.Dataset(
            data_vars={
                'bathymetry': (('lat', 'lon'), bathy),
            },
            coords={
                'lat': y,
                'lon': x,
            },
        )
        ds.to_netcdf(fname_out)
        print(f"Saved to {fname_out}")
