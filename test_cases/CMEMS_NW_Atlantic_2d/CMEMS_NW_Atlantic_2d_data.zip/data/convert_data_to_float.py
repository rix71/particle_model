import xarray as xr
df = xr.open_dataset('./hydro/cmems_hydro.nc')
encoding = {"uo": {"dtype": "float32"}, "vo": {"dtype": "float32"}}
df.isel(longitude=slice(11, -11), latitude=slice(11, -11)).to_netcdf('./hydro/cmems_hydro_float.nc', encoding=encoding)
